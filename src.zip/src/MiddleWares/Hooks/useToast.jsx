
const useToast = () => {
  return (
    <div>useToast</div>
  )
}

export default useToast